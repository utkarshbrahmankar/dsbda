import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class Music {
	public static void main(String[] args) throws Exception{
		Path input = new Path(args[0]);
		Path output = new Path(args[1]);
		String choice = args[2];
		
		Job job = new Job();
		job.setJarByClass(Music.class);
		
		if(choice.equals("skip")){
			job.setJobName("Music skip");
			job.setMapperClass(MusicSkip.class);
		} else if(choice.equals("share")){
			job.setJobName("Music share");
			job.setMapperClass(MusicShare.class);
		} else if(choice.equals("radio")){
			job.setJobName("Music radio");
			job.setMapperClass(MusicRadio.class);
		}
		else if(choice.equals("listener")){
    		job.setJobName("Unique Listeners");
    		job.setMapperClass(MusicListener.class);
    		job.setReducerClass(MusicListenerReducer.class);
    		job.setMapOutputKeyClass(Text.class);
    		job.setMapOutputValueClass(Text.class);
    		job.setOutputKeyClass(Text.class);
    		job.setOutputValueClass(IntWritable.class);
		}

		job.setReducerClass(MusicReducer.class);
		
		FileInputFormat.setInputPaths(job, input);
		FileOutputFormat.setOutputPath(job, output);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		boolean success = job.waitForCompletion(true);
		System.exit(success ? 0 : 1);
	}
}
