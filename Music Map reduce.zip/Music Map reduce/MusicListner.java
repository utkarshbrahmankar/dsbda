import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Mapper;

public class MusicListener extends Mapper<LongWritable, Text, Text, Text> {
    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] fields = value.toString().split(",");
        if(fields[0].equals("UserId")) return;
        try {
            if(fields.length == 5){
                String userId = fields[0];
                String trackId = fields[1];
                context.write(new Text(trackId), new Text(userId));
            }
        } catch(Exception e) {
            // skip invalid rows
        }
    }
}
