import java.io.IOException;
import java.util.HashSet;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MusicListenerReducer extends Reducer<Text, Text, Text, IntWritable> {
    @Override
    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        HashSet<String> uniqueUsers = new HashSet<>();
        for(Text user : values){
            uniqueUsers.add(user.toString());
        }
        context.write(key, new IntWritable(uniqueUsers.size()));
    }
}
