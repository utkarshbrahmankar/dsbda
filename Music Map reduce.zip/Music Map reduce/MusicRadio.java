import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MusicRadio extends Mapper<LongWritable, Text, Text, IntWritable>{
	@Override
	public void map(LongWritable key, Text value,Context context) throws IOException{
		String[] fields = value.toString().split(",");
		if(fields[0].equals("UserId")) return;
		try{
			if(fields.length == 5){				
				String track = fields[1];
				int radio = Integer.parseInt(fields[3]);
				context.write(new Text(track), new IntWritable(radio));
			}
		} catch(Exception e){
			// skip row
		}
	}
}
